GraphAnalyse - Frontend (React)

Requirements:
- Node.js (14+)

Setup:
  npm install

Run:
  npm start
